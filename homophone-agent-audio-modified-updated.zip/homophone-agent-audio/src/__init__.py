# This package exposes the core components of the homophonic–literal
# dual translation agent. Modules are documented individually.
